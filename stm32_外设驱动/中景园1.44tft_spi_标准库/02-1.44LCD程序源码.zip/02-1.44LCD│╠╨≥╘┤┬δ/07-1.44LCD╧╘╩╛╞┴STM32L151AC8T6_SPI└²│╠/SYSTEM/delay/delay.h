#ifndef _DELAY_H
#define _DELAY_H

#include "stm32l1xx_hal.h"


void delay_ms(uint32_t ms);

#endif



